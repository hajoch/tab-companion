/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/background.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background.js":
/*!***************************!*\
  !*** ./src/background.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// https://developer.chrome.com/extensions/background_pages

var collapsed_state = false;

//--------------------------
//  EVENT LISTENERS
//--------------------------

chrome.commands.onCommand.addListener( (command) => {
	switch(command) {
		case 'create-group':
			createGroup(); break;
		case 'create-tab':
			createTab(); break;
		case 'toggle-all-groups':
			toggleAllGroups(); break;
		case 'close-group':
			closeGroup(); break;
		default:
			console.log(`Command ${command} not found`);
	}
});

//--------------------------
//   MAIN ENTRY FUNCTIONS
//--------------------------


async function closeGroup() {
	let [tab] = await getCurrentTab();
	if(tab.groupId) {
		let groupTabs = await chrome.tabs.query({groupId: tab.groupId});
		groupTabs.forEach(tab => {
			chrome.tabs.remove(tab.id);
		});
	}
}

async function toggleAllGroups() {
	collapsed_state = !collapsed_state;
	let [tab] = await getCurrentTab();
	// Get all groups in current window
	let groups = await chrome.tabGroups.query({ windowId: chrome.windows.WINDOW_ID_CURRENT });
	//Toggle all but the currently active group
	groups.forEach((group) => {
		if(!tab.groupId || tab.groupId != group.id ){
			toggleGroup(group, collapsed_state);
		}
	});
}

async function createGroup() {
	//GET CURRENT TAB INFO
	let [tab] = await getCurrentTab();
	// PROMPT USER FOR TITLE
	let options = await getOptions();
	if(options.promptName) {
		//For some reason the promise doesn't work.... 😒
		//TODO - Investigate
		chrome.tabs.sendMessage(tab.id, {
			type: 'GROUPTITLE',
			payload: {
				message: suggestTitle(tab)
			}
		}, (response) => { 
			createGroupByTab(tab, (response || {}).message);
		});
	} else {
		createGroupByTab(tab);
	}
}


async function createTab() {
	let [current] = await getCurrentTab();
	const props = {
		active: true,
		openerTabId: current.id,
	}
	let newTab = await chrome.tabs.create(props);
	chrome.tabs.group({ groupId: current.groupId, tabIds: newTab.id });
}

//--------------------------
//     HELPER FUNCTIONS
//--------------------------

async function createGroupByTab(tab, groupName) {
	groupName = groupName || suggestTitle(tab);
	//GREATE GROUP
	let groupId = await chrome.tabs.group({ tabIds: tab.id });
	//NAME GROUP
	await chrome.tabGroups.update(groupId, { 
		title: groupName 
	});
	console.log(`Group ${groupId} created with title ${groupName}`);
}

function toggleGroup(group, collapsed) {
	chrome.tabGroups.update(group.id, {collapsed: collapsed });
}

// TODO - Should probably rename to "Settings"
// TODO - There's also a possiblity of the options not being in sync initially.. Simple fix
function getOptions() {
	return chrome.storage.sync.get('options');
}

function getCurrentTab() {
	const queryOptions = { active: true, currentWindow: true };
	return chrome.tabs.query(queryOptions);
}

function suggestTitle(tab) {
	const tab_title = tab.title || 'New Group';
	return tab_title.substring(0, tab_title.length > 36 ? 36: tab_title.length);
}


/*
chrome.tabGroups.onCreated.addListener( (group) => {
	autoCollapse();
});

chrome.storage.onChanged.addListener((changes, area) => {
	let newValue = (changes.options || {}).newValue;
	if(area === 'sync' && newValue) {
		// options = newValue;
		//Do updates based on settings
		autoCollapse(newValue);
	}
});

async function autoCollapse(options) {
	if(!options) options = await getOptions();
	if(options.autoCollapse) {
		collapsed_state = false;
		toggleAllGroups();
	}
}
*/


/***/ })

/******/ });
//# sourceMappingURL=background.js.map